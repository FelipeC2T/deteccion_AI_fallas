import tensorflow as tf
# unet (1.5 million parameters) and Bigunet (9 million parameters)

def unet(pretrained_weights = None,input_size = (None,None,None,1)):

    inputs = tf.keras.layers.Input(input_size)

    conv1 = tf.keras.layers.Conv3D(16, (3,3,3), activation='relu', padding='same')(inputs)
    conv1 = tf.keras.layers.Conv3D(16, (3,3,3), activation='relu', padding='same')(conv1)
    pool1 = tf.keras.layers.MaxPooling3D(pool_size=(2,2,2))(conv1)

    conv2 = tf.keras.layers.Conv3D(32, (3,3,3), activation='relu', padding='same')(pool1)
    conv2 = tf.keras.layers.Conv3D(32, (3,3,3), activation='relu', padding='same')(conv2)
    pool2 = tf.keras.layers.MaxPooling3D(pool_size=(2,2,2))(conv2)

    conv3 = tf.keras.layers.Conv3D(64, (3,3,3), activation='relu', padding='same')(pool2)
    conv3 = tf.keras.layers.Conv3D(64, (3,3,3), activation='relu', padding='same')(conv3)
    pool3 = tf.keras.layers.MaxPooling3D(pool_size=(2,2,2))(conv3)

    conv4 = tf.keras.layers.Conv3D(128, (3,3,3), activation='relu', padding='same')(pool3)
    conv4 = tf.keras.layers.Conv3D(128, (3,3,3), activation='relu', padding='same')(conv4)

    #up5 = tf.keras.layers.concatenate([tf.keras.layers.UpSampling3D(size=(2,2,2))(conv4), conv3], axis=-1)
    up5 = tf.concat([tf.keras.layers.UpSampling3D(size=(2,2,2))(conv4), conv3], axis=-1)
    
    conv5 = tf.keras.layers.Conv3D(64, (3,3,3), activation='relu', padding='same')(up5)
    conv5 = tf.keras.layers.Conv3D(64, (3,3,3), activation='relu', padding='same')(conv5)

    #up6 = tf.keras.layers.concatenate([tf.keras.layers.UpSampling3D(size=(2,2,2))(conv5), conv2], axis=-1)
    up6 = tf.concat([tf.keras.layers.UpSampling3D(size=(2,2,2))(conv5), conv2], axis=-1)
    conv6 = tf.keras.layers.Conv3D(32, (3,3,3), activation='relu', padding='same')(up6)
    conv6 = tf.keras.layers.Conv3D(32, (3,3,3), activation='relu', padding='same')(conv6)

    #up7 = tf.keras.layers.concatenate([tf.keras.layers.UpSampling3D(size=(2,2,2))(conv6), conv1], axis=-1)
    up7 = tf.concat([tf.keras.layers.UpSampling3D(size=(2,2,2))(conv6), conv1], axis=-1)
    conv7 = tf.keras.layers.Conv3D(16, (3,3,3), activation='relu', padding='same')(up7)
    conv7 = tf.keras.layers.Conv3D(16, (3,3,3), activation='relu', padding='same')(conv7)

    conv8 = tf.keras.layers.Conv3D(1, (1,1,1), activation='sigmoid')(conv7)

    model = tf.keras.models.Model(inputs=[inputs], outputs=[conv8])

    return model

def Bigunet(pretrained_weights = None,input_size = (None,None,None,1)):

    inputs = tf.keras.layers.Input(input_size)

    conv1 = tf.keras.layers.Conv3D(16, (3,3,3), activation='relu', padding='same')(inputs)
    conv1 = tf.keras.layers.Conv3D(16, (3,3,3), activation='relu', padding='same')(conv1)
    pool1 = tf.keras.layers.MaxPooling3D(pool_size=(2,2,2))(conv1)

    conv2 = tf.keras.layers.Conv3D(32, (3,3,3), activation='relu', padding='same')(pool1)
    conv2 = tf.keras.layers.Conv3D(32, (3,3,3), activation='relu', padding='same')(conv2)
    pool2 = tf.keras.layers.MaxPooling3D(pool_size=(2,2,2))(conv2)

    conv3 = tf.keras.layers.Conv3D(64, (3,3,3), activation='relu', padding='same')(pool2)
    conv3 = tf.keras.layers.Conv3D(64, (3,3,3), activation='relu', padding='same')(conv3)
    pool3 = tf.keras.layers.MaxPooling3D(pool_size=(2,2,2))(conv3)

    conv4 = tf.keras.layers.Conv3D(512, (3,3,3), activation='relu', padding='same')(pool3)
    conv4 = tf.keras.layers.Conv3D(512, (3,3,3), activation='relu', padding='same')(conv4)

    up5 = tf.keras.layers.concatenate([tf.keras.layers.UpSampling3D(size=(2,2,2))(conv4), conv3], axis=-1)
    conv5 = tf.keras.layers.Conv3D(64, (3,3,3), activation='relu', padding='same')(up5)
    conv5 = tf.keras.layers.Conv3D(64, (3,3,3), activation='relu', padding='same')(conv5)

    up6 = tf.keras.layers.concatenate([tf.keras.layers.UpSampling3D(size=(2,2,2))(conv5), conv2], axis=-1)
    conv6 = tf.keras.layers.Conv3D(32, (3,3,3), activation='relu', padding='same')(up6)
    conv6 = tf.keras.layers.Conv3D(32, (3,3,3), activation='relu', padding='same')(conv6)

    up7 = tf.keras.layers.concatenate([tf.keras.layers.UpSampling3D(size=(2,2,2))(conv6), conv1], axis=-1)
    conv7 = tf.keras.layers.Conv3D(16, (3,3,3), activation='relu', padding='same')(up7)
    conv7 = tf.keras.layers.Conv3D(16, (3,3,3), activation='relu', padding='same')(conv7)

    conv8 = tf.keras.layers.Conv3D(1, (1,1,1), activation='sigmoid')(conv7)

    model = tf.keras.models.Model(inputs=[inputs], outputs=[conv8])

    return model
