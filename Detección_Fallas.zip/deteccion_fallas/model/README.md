please download the pretrained model "pretrained_model.hdf5" from https://drive.google.com/drive/folders/1q8sAoLJgbhYHRubzyqMi9KkTeZWXWtNd

one 05/07/2020, three new trained models are uploaded for testing

Modelo entrenado por FC "weights.h5" y "history.npy" hacer unzip.