Por favor descargue el dataset "gxl.dat" (subset del bloque F3) que se encuentra dentro de "prediction":

https://drive.google.com/file/d/1yG_tuJEo2DMiiDmbmGMw3hdAZfkhlONE/view?usp=sharing
