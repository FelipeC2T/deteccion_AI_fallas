**200 fault volumes:**


please download fault.zip from: https://drive.google.com/file/d/1qjw-4z3fU47yZk00h-8CfNQXc92tSHhg/view?usp=sharing
(do not be surprised by the small size of the compressed package fault.zip, just because the fault labels are mostly zeros)

**200 seismic volumes:**

please download the training seismic data from https://drive.google.com/open?id=1I-kBAfc_ag68xQsYgAHbqWYdddk4XHHd

