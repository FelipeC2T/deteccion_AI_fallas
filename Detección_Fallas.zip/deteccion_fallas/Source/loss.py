import tensorflow as tf
import numpy as np
# Original (updated from faultSeg repository)
@tf.function
def cross_entropy_balanced(y_true, y_pred):
    # Note: tf.nn.sigmoid_cross_entropy_with_logits expects y_pred is logits, 
    # Keras expects probabilities.
    # transform y_pred back to logits
    #_epsilon = _to_tensor(tf.keras.backend.epsilon(), y_pred.dtype.base_dtype)
    _epsilon = tf.keras.backend.epsilon()        
    
    y_pred   = tf.clip_by_value(y_pred, _epsilon, 1 - _epsilon)
    
    
    #y_pred   = tf.log(y_pred/ (1 - y_pred))
    y_pred   = tf.math.log(y_pred/ (1 - y_pred))

    y_true = tf.cast(y_true, tf.float32)

    count_neg = tf.reduce_sum(1. - y_true)
    count_pos = tf.reduce_sum(y_true)

    beta = count_neg / (count_neg + count_pos)

    pos_weight = beta / (1 - beta)

    #cost = tf.nn.weighted_cross_entropy_with_logits(logits=y_pred, targets=y_true, pos_weight=pos_weight)
    ## the positional argument `targets` => `labels`
    cost = tf.nn.weighted_cross_entropy_with_logits(logits= y_pred, labels=y_true,  pos_weight=pos_weight)   
    cost = tf.reduce_mean(cost * (1 - beta))
    
    return tf.where(tf.equal(count_pos, 0.0), 0.0, cost)

# My custom loss (readable for the interested researcher):
@tf.function
def cross_entropy_balanced_JLG(y_true, y_pred):
    
    #_epsilon = _to_tensor(K.epsilon(), y_pred.dtype.base_dtype)  # this is just 1e-07 in my notebook    
    #_epsilon = tf.constant(1e-07,dtype="float32")
    _epsilon = tf.keras.backend.epsilon()        
    
    # tf.clip_by_value: Clips tensor values to a specified min and max.
    y_pred  = tf.clip_by_value(y_pred, clip_value_min = _epsilon, clip_value_max = 1.0 - _epsilon) # 0<y_pred<1 to be "probability"
       
    y_true = tf.cast(y_true, tf.float32)

    # Weight: 
    total     = len(tf.reshape(y_true,[-1]))
    total     = tf.cast(total,tf.float32)
    count_pos = tf.reduce_sum(y_true)
    beta      = tf.math.divide_no_nan(total-count_pos,total)

    cost = beta * y_true * -tf.math.log(y_pred) + (1.-beta)*(1.-y_true)*-tf.math.log(1.0-y_pred)
    cost = tf.reduce_mean(cost) # mean over batch
    #cost = tf.math.divide_no_nan(tf.experimental.numpy.nansum(cost),total) # mean over batch
    return tf.where(tf.equal(count_pos, 0.0), 0.0, cost)

# Weighted binary cross-entropy:
@tf.function
def BinaryCrossentropyBalanced(y_true,y_pred):
    
    _epsilon = tf.keras.backend.epsilon()        
    
    y_pred  = tf.clip_by_value(y_pred, clip_value_min = _epsilon, clip_value_max = 1.0 - _epsilon) # 0<y_pred<1 to be "probability"
       
    y_true = tf.cast(y_true, tf.float32)

    count_neg = tf.reduce_sum(1. - y_true)
    count_pos = tf.reduce_sum(y_true)

    beta = count_neg / (count_neg + count_pos)
    
    pos_weight = beta / (1. - beta)
    
    bce  = tf.keras.losses.BinaryCrossentropy(from_logits=False,reduction=tf.keras.losses.Reduction.NONE)
    cost = bce(y_true,y_pred, sample_weight = pos_weight )
    cost = tf.reduce_mean(cost * (1. - beta ))
    
    return tf.where(tf.equal(count_pos, 0.0), 0.0, cost)

# Explicit cross entropy
@tf.function
def cross_entropy_balanced_NAKED(y_true, y_pred):
    # Note: tf.nn.sigmoid_cross_entropy_with_logits expects y_pred is logits, 
    # Keras expects probabilities.
    # transform y_pred back to logits
    
    _epsilon = tf.keras.backend.epsilon()        
    # tf.clip_by_value: Clips tensor values to a specified min and max.
    y_pred  = tf.clip_by_value(y_pred, clip_value_min = _epsilon, clip_value_max = 1. - _epsilon) # 0<y_pred<1 to be "probability"
       
    y_true = tf.cast(y_true, tf.float32)

    count_neg = tf.reduce_sum(1. - y_true)
    count_pos = tf.reduce_sum(y_true)

    beta       = count_neg / (count_neg + count_pos)
    pos_weight = beta / (1 - beta)
    
    # 1) The original code:
    #y_pred_logits = tf.math.log(y_pred / (1.0 - y_pred)) # logit(p) =   log(p / (1 - p) )
    #cost          = tf.nn.weighted_cross_entropy_with_logits(logits= y_pred_logits, labels=y_true,  pos_weight=pos_weight)
    
    ## 2) Using explicit function logits=true means inputs are sigmoid(something) :
    ## when y_pred was transform back to logits
    #y_pred_logits  = tf.math.log(y_pred / (1.0 - y_pred)) # logit(p) =   log(p / (1 - p) )       
    #cost    =  - ( y_true * tf.math.log(tf.nn.sigmoid(y_pred_logits)) * pos_weight +  (1.0 - y_true) * tf.math.log(1.0 - tf.nn.sigmoid(y_pred_logits)) )
  
    ## 3) Using y_pred as given (without logit transform):
    cost =   - (y_true * tf.math.log(y_pred) * pos_weight +  (1.0 - y_true) * tf.math.log(1.0 - y_pred))
    
    cost = tf.reduce_mean(cost * (1 - beta)) # mean over batch

    return tf.where(tf.equal(count_pos, 0.0), 0.0, cost)

@tf.function
def FocalLoss(y_true, y_pred,
              alpha: tf.constant = 0.25,
              gamma: tf.constant = 2.0):
    """Custom Focal Loss"""
    _epsilon = tf.keras.backend.epsilon()            
    y_pred   = tf.clip_by_value(y_pred, _epsilon, 1 - _epsilon)
    y_true   = tf.cast(y_true, tf.float32)   
    
    pt       = (y_true * y_pred) + (1. - y_true) * (1. - y_pred) # yields: y_pred or 1-y_pred
    factor   = alpha * tf.math.pow(1. - pt, gamma) 
    
    cost = y_true * -tf.math.log(y_pred) + (1.-y_true) * -tf.math.log(1. - y_pred)  
    
    cost = tf.math.multiply(cost,factor)
    
    # Easier to read:
    #cost = y_true * tf.math.pow(1. - y_pred, gamma) * -tf.math.log(y_pred) +  (1.-y_true)*tf.math.pow(y_pred, gamma)* -tf.math.log(1. - y_pred)  
    #cost = tf.math.multiply(alpha,cost)    
    return tf.reduce_mean(cost)

@tf.function
def smoothed_dice_loss(y_true, y_pred):
    # From Gao et al. (2022): Automatic fault detection on seismic images using a multiscale attention
    # convolutional neural network. 
    # http://mr.crossref.org/iPage?doi=10.1190%2Fgeo2020-0945.1
    #_epsilon = tf.keras.backend.epsilon()
    #y_pred   = tf.clip_by_value(y_pred, clip_value_min = _epsilon, clip_value_max = 1.0 - _epsilon) # 0<y_pred<1 to be "probability"       
    y_true   = tf.cast(y_true, tf.float32)
    #axis = [1,2,3]
    axis = -1
    num  = 2.0*tf.reduce_sum( tf.math.multiply(y_true, y_pred), axis=axis) #+ 1.0
    dem  = tf.reduce_sum(y_true,axis=axis) + tf.reduce_sum(y_pred, axis=axis) #+ 1.0
    num  = tf.add(1.0, num)
    dem  = tf.add(1.0, dem)    
    #cost = 1.0 - tf.math.xdivy(num,dem)
    cost = tf.subtract(1.0, tf.math.xdivy(num,dem))
    return  tf.reduce_mean(cost)

@tf.function
#funcion definida por GPT3
def smooth_dice_lossGPT(y_true, y_pred, smooth=1e-5):
    y_true_f = tf.keras.layers.Flatten()(y_true)
    y_pred_f = tf.keras.layers.Flatten()(y_pred)
    intersection = tf.reduce_sum(y_true_f * y_pred_f)
    sdl=(2. * intersection + smooth) / (tf.reduce_sum(y_true_f) + tf.reduce_sum(y_pred_f) + smooth)
    cost=tf.subtract(1.0,sdl)
    return tf.reduce_mean(cost)
