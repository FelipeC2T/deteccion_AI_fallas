import numpy as np
def PatchProcessAssemble( x , mask = np.ones((10,10,10)), step = 5 ):

    m1,m2,m3 = np.shape(x)
    w1,w2,w3 = np.shape(mask) # patch size from the masked to be applied to each patch.
    
    y  = np.zeros_like(x,dtype="float")
    yn = np.zeros_like(x,dtype="float") # to normalize the overlapping patches
    
    # Any data is left out when slicing? If remainder is not zero, add an extra window at the
    # end which covers the last samples.
    
    r1 = (m1-w1) % step
    r2 = (m2-w2) % step
    r3 = (m3-w3) % step
    #print("Samples left:", r1,r2,r3 )
    
    extra1, extra2, extra3 = 0, 0, 0    
    if r1 > 0: extra1 = 1; # print("Adding extra window in direction 1")
    if r2 > 0: extra2 = 1; # print("Adding extra window in direction 2")
    if r3 > 0: extra3 = 1; # print("Adding extra window in direction 3")
        
    # number of windows ( +1 since I already count one window in (m1-w1), etc.
    nw1 = ( (m1-w1)//step + 1 ) 
    nw2 = ( (m2-w2)//step + 1 ) 
    nw3 = ( (m3-w3)//step + 1 ) 
    
    print("Total patches to extract:",(nw1+extra1)*(nw2+extra2)*(nw3+extra3))
    print("Patch size:",w1,w2,w3)
    print("Step:",step)  
    # Window to apply prior to prediction
    
    
    for id1 in range(nw1+extra1): # `+1` to fill the remainding space
        if id1 == nw1:            
            s1,e1 = m1-w1, m1
        else: # fill the remainding space
            s1 = id1*step
            e1 = s1+w1        
            
        for id2 in range(nw2+extra2):
            if id2 == nw2:  
                s2,e2 = m2-w2, m2
            else:
                s2 = id2*step
                e2 = s2+w2        

            for id3 in range(nw3+extra3):                
                if id3 == nw3:            
                    s3,e3 = m3-w3, m3
                else:
                    s3 = id3*step
                    e3 = s3+w3        
                    
                patch = x[s1:e1,s2:e2,s3:e3]
                
                #assert np.shape(patch) == (w1,w2,w3) # check size (debugging)                
                
                # PROCESSING:                
                #gs = Normalize(patch * mask )       # algunas fallas internas se ven mejor, pero mucho artifact en el borde            
                gs = Normalize(patch)            # aceptable
                
                yy = model.predict(tf.reshape(gs,(1,n1,n2,n3,1)),verbose=1)  
                yy = tf.squeeze(yy).numpy()
                
                y [s1:e1,s2:e2,s3:e3] += yy * mask  # assemble
                yn[s1:e1,s2:e2,s3:e3] += mask
                
    nonzero = yn != 0.
    y[nonzero]  = y[nonzero] / yn[nonzero]  # remove overlapping between patches
    #y[~nonzero] = x[~nonzero] # # copy original values where no patch was applied. 
    return y #, yn

def Normalize(x):
    # see tf.image.per_image_standardization
    N      = len(x)
    mean   = np.mean(x)
    stddev = np.std(x)
    stddev = np.maximum(stddev, 1.0/np.sqrt(N)) # protect againts division by zero
    return (x - mean) / stddev # 

def Mask(n1,n2,n3,M):
    # una ventana triangular empieza en "0", la gaussiana no. Revisar si esto no hace ralentiza el training 
    #tri = np.arange(M)
    
    # Triangular window:
    #tri = np.arange(1,M+1) # esta ventana empieza en "1"
    #tri = tri / M
    
    # Hann window:
    #N   = 2*M+1
    #n   = np.arange(M)
    #tri = (1 - np.cos(2*np.pi*n/(N-1)))/2;
    
    # Hamming
    N   = 2*M+1
    n   = np.arange(M)
    tri = 0.54 - 0.46*np.cos(2*np.pi*n/(N-1))
    
    W   = np.ones(n1*n2*n3).reshape(n1,n2,n3)
    
    for j in range(n2):
        for k in range(n3):        
            W[0:M,j,k]     *= tri
            W[n1-M:n1,j,k] *= tri[::-1]
    for i in range(n1):
        for j in range(n2):        
            W[i,j,0:M]     *= tri
            W[i,j,n1-M:n1] *= tri[::-1]
    for i in range(n1):
        for k in range(n3):        
            W[i,0:M,k]     *= tri
            W[i,n1-M:n1,k] *= tri[::-1]        
    return W